This is Version 0.2 of the 4Bit Demo Computer.

DemoComputer was developed in 1999 by Beno Kurmann and Michel Marti.

This software is freely distributable under the GNU public license,
a copy of which you should have received with this software (in a
file called "copying.txt").
